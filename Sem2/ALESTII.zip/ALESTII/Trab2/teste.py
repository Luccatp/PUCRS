class Grafo:
    def __init__(self, mapa):
        self.mapa = mapa
        self.linhas = len(mapa)
        self.colunas = len(mapa[0])
        self.vertices = set()
        self.arestas = {}

    def adicionar_vertice(self, vertice):
        self.vertices.add(vertice)
        self.arestas[vertice] = []

    def adicionar_aresta(self, vertice1, vertice2):
        self.arestas[vertice1].append(vertice2)
        self.arestas[vertice2].append(vertice1)

    def criar_grafo(self):
        for i in range(self.linhas):
            for j in range(self.colunas):
                if self.mapa[i][j] == '*':
                    continue
                vertice = (i, j)
                self.adicionar_vertice(vertice)
                if i > 0 and self.mapa[i - 1][j] != '*':
                    self.adicionar_aresta(vertice, (i - 1, j))
                if i < self.linhas - 1 and self.mapa[i + 1][j] != '*':
                    self.adicionar_aresta(vertice, (i + 1, j))
                if j > 0 and self.mapa[i][j - 1] != '*':
                    self.adicionar_aresta(vertice, (i, j - 1))
                if j < self.colunas - 1 and self.mapa[i][j + 1] != '*':
                    self.adicionar_aresta(vertice, (i, j + 1))

from collections import deque

def encontrar_trajeto(mapa, ponto_partida, ponto_destino):
    grafo = Grafo(mapa)
    grafo.criar_grafo()

    fila = deque([(ponto_partida, 0)])  # (vertice, distancia)
    visitados = set()

    while fila:
        vertice, distancia = fila.popleft()
        if vertice == ponto_destino:
            return distancia
        if vertice in visitados:
            continue
        visitados.add(vertice)
        for vizinho in grafo.arestas[vertice]:
            fila.append((vizinho, distancia + 1))

    return -1  # Não foi encontrado um caminho válido

def processar_casos_teste(casos_teste):
    resultados = []
    for mapa in casos_teste:
        ponto_partida