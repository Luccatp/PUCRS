#include "quadtree.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#ifdef __APPLE__
#include <OpenGL/gl.h>
#else
#include <GL/gl.h> /* OpenGL functions */
#endif

unsigned int first = 1;
char desenhaBorda = 1;

RGBPixel *pixels;
int initialHeight = 0;
int initialWidth = 0;

float calculaErro(int x, int y, int initialWidth, int initialHeight, RGBPixel *pixels, int matriz[initialHeight][initialWidth], float media);
RGBPixel calculaCorMedia(int x, int y, int initialWidth, int initialHeight, RGBPixel *pixels);
QuadNode *recursiveTree(int x, int y, int initialWidth, int initialHeight, RGBPixel *pixels, float minError, int matriz[initialHeight][initialWidth]);
float calculaMedia(int x, int y, RGBPixel *pixels, int initialWidth, int initialHeight);

QuadNode *newNode(int x, int y, int width, int height)
{
    QuadNode *n = malloc(sizeof(QuadNode));
    n->x = x;
    n->y = y;
    n->width = width;
    n->height = height;
    n->NW = n->NE = n->SW = n->SE = NULL;
    n->color[0] = n->color[1] = n->color[2] = 0;
    n->id = first++;
    return n;
}

QuadNode *geraQuadtree(Img *pic, float minError)
{
    // Converte o vetor RGBPixel para uma MATRIZ que pode acessada por pixels[linha][coluna]
    RGBPixel(*pixels_ex)[pic->width] = (RGBPixel(*)[pic->height])pic->img;

    // Veja como acessar os primeiros 10 pixels da imagem, por exemplo:
    int i;
    for (i = 0; i < 10; i++)
        printf("%02X %02X %02X\n", pixels_ex[0][i].r, pixels_ex[1][i].g, pixels_ex[2][i].b);

    int width = pic->width;
    int height = pic->height;

    initialHeight = height;
    initialWidth = width;

    pixels = &pixels_ex[0][0];

    int matrizCinza[initialWidth][initialHeight];

    for (int i = 0; i < initialHeight; i++)
    {
        for (int j = 0; j < initialWidth; j++)
        {
            matrizCinza[i][j] = 9;
        }
    }

    //////////////////////////////////////////////////////////////////////////
    // Implemente aqui o algoritmo que gera a quadtree, retornando o nodo raiz
    //////////////////////////////////////////////////////////////////////////

    QuadNode *raiz = recursiveTree(0, 0, initialWidth, initialHeight, pixels, minError, matrizCinza);

    return raiz;

    // COMENTE a linha abaixo quando seu algoritmo ja estiver funcionando
    // Caso contrario, ele ira gerar uma arvore de teste com 3 nodos

    // #define DEMO
    // #ifdef DEMO

    //     /************************************************************/
    //     /* Teste: criando uma raiz e dois nodos a mais              */
    //     /************************************************************/

    //     QuadNode *raiz = newNode(0, 0, width, height);
    //     raiz->status = PARCIAL;
    //     raiz->color[0] = 0;
    //     raiz->color[1] = 0;
    //     raiz->color[2] = 255;

    //     int meiaLargura = width / 2;
    //     int meiaAltura = height / 2;

    //     QuadNode *nw = newNode(meiaLargura, 0, meiaLargura, meiaAltura);
    //     nw->status = PARCIAL;
    //     nw->color[0] = 0;
    //     nw->color[1] = 0;
    //     nw->color[2] = 255;

    //     // Aponta da raiz para o nodo nw
    //     raiz->NW = nw;

    //     QuadNode *nw2 = newNode(meiaLargura + meiaLargura / 2, 0, meiaLargura / 2, meiaAltura / 2);
    //     nw2->status = CHEIO;
    //     nw2->color[0] = 255;
    //     nw2->color[1] = 0;
    //     nw2->color[2] = 0;

    //     // Aponta do nodo nw para o nodo nw2
    //     nw->NW = nw2;

    // #endif
    //     // Finalmente, retorna a raiz da árvore
    //     return raiz;
}

QuadNode *recursiveTree(int x, int y, int initialWidth, int initialHeight, RGBPixel *pixels, float minError, int matrizCinza[initialHeight][initialWidth]) //
{
    QuadNode *node = newNode(x, y, initialWidth, initialHeight); // cria um nodo

    RGBPixel corMedia = calculaCorMedia(x, y, initialWidth, initialHeight, pixels); // calcula a cor media do nodo

    node->color[0] = corMedia.r; // seta a cor red do nodo
    node->color[1] = corMedia.g; // seta a cor green do nodo
    node->color[2] = corMedia.b; // seta a cor blue do nodo

    int halfHeight = initialHeight / 2; // pega metade da altura do nodo
    int halfWidth = initialWidth / 2;   // pega metade da largura do nodo

    float media = calculaMedia(x, y, pixels, initialWidth, initialHeight);
    float erro = calculaErro(x, y, initialWidth, initialHeight, pixels, matrizCinza, media); // manda pra função que calcula o erro

    printf("Erro: %ld\n", erro); // printa o erro

    if (erro < minError && halfHeight > 0 && halfWidth > 0) // verifica se o erro é menor que o erro minimo definido e se a altura e largura do nodo são maiores que 0 para ver se não esta pegando a região de um pixel só.
    {
        // se for seta o status do nodo como cheio e retorna o nodo
        node->status = CHEIO;
        return node;
    }
    else
    {
        node->status = PARCIAL;                // seta o status do nodo como parcial
        if (halfHeight == 1 && halfWidth == 1) // se não verifica se o nodo tem altura e largura igual a 1
        {
            // seta os status dos nodos filhos como cheio e retorna o nodo
            node->NW->status = CHEIO;
            node->NE->status = CHEIO;
            node->SW->status = CHEIO;
            node->SE->status = CHEIO;

            return node;
        }

        // chama a função recursivamente para cada nodo filho e retorna o nodo atual
        node->NW = recursiveTree(x, y, halfWidth, halfHeight, pixels, minError, matrizCinza);
        node->NE = recursiveTree(x + halfWidth, y, halfWidth, halfHeight, pixels, minError, matrizCinza);
        node->SW = recursiveTree(x, y + halfHeight, halfWidth, halfHeight, pixels, minError, matrizCinza);
        node->SE = recursiveTree(x + halfWidth, y + halfHeight, halfWidth, halfHeight, pixels, minError, matrizCinza);
        // assim seguindo a recursividade da arvore, caminhando por cada nodo descendo até o ultimo nodo que terá altura e largura igual a 1
        return node;
    }
}

float calculaMedia(int x, int y, RGBPixel *pixels, int initialWidth, int initialHeight)
{
    int numPixels = initialWidth * initialHeight;
    int soma = 0;
    float media = 0.0;
    for (int i = x; i < x + initialHeight; i++)
    {
        for (int j = y; j < y + initialWidth; j++)
        {
            unsigned char valorPixel = pixels[i * initialWidth + j].r;
            soma += valorPixel;
        }
    }
    if (numPixels != 0)
    { // Evita divisão por zero VERIFICAR ISSO ----------------------------------------------------
        media = soma / numPixels;
    }
    return media;
}

float calculaErro(int x, int y, int initialWidth, int initialHeight, RGBPixel *pixels, int matriz[initialHeight][initialWidth], float media) // Calcula o erro de um bloco
{
    // inicia calculo 3.3.1

    int histograma[256] = {0}; // inicializa o histograma com 0 alocando 256 posições

    for (int i = y; i < y + initialHeight; i++) // Percorre a matriz de pixels
    {
        for (int j = x; j < x + initialWidth; j++) // Percorre a matriz de pixels
        {
            int indexMatriz = i * initialWidth + j; // Calcula o indice atual da matriz, considerando uma dimensão.

            unsigned char r = pixels[indexMatriz].r; // pega o valor vermelho do pixel
            unsigned char g = pixels[indexMatriz].g; // pega o valor verde do pixel
            unsigned char b = pixels[indexMatriz].b; // pega o valor azul do pixel

            int intensidade = ((r * 0.3) + (g * 0.59) + (b * 0.11)); // Calcula a intensidade do pixel

            histograma[intensidade]++; // Incrementa o histograma
        }
    }

    ; // termina 3.3.1

    // inicia 3.3.2

    float erro = 0;                             // Inicializa o erro
    for (int i = y; i < y + initialHeight; i++) // somatorio height
    {
        for (int j = x; j < x + initialWidth; j++) // somatorio width
        {
            int indexMatriz = i * initialWidth + j; // Calcula o indice da matriz

            unsigned char r = pixels[indexMatriz].r; // Pega o valor do pixel na matriz
            unsigned char g = pixels[indexMatriz].g; // Pega o valor do pixel na matriz
            unsigned char b = pixels[indexMatriz].b; // Pega o valor do pixel na matriz

            int intensidade = ((r * 0.3) + (g * 0.59) + (b * 0.11)); // Calcula a intensidade do pixel na posição i j

            erro += pow(intensidade - media, 2); // intensidade - media ao quadrado
        }
    }

    erro = sqrt((1 / (initialWidth * initialHeight)) * erro); // faz o calculo interno                                 //  faz a raiz quadrada do erro
    return erro;                                              // Retorna o erro
}

// calcula cor media de um bloco de pixels
RGBPixel calculaCorMedia(int x, int y, int initialWidth, int initialHeight, RGBPixel *pixels)
{
    int totalR = 0, totalG = 0, totalB = 0; // total de cada cor
    int count = 0;                          // total de pixels

    for (int i = y; i < y + initialHeight; i++) // percorre a matriz de pixels
    {
        for (int j = x; j < x + initialWidth; j++) // percorre a matriz de pixels
        {
            int indexMatriz = i * initialWidth + j; // calcula o indice do pixel na matriz
            totalR += pixels[indexMatriz].r;        // soma o valor da cor red
            totalG += pixels[indexMatriz].g;        // soma o valor da cor green
            totalB += pixels[indexMatriz].b;        // soma o valor da cor blue
            count++;                                // incrementa o total de pixels
        }
    }

    RGBPixel corMedia; // cria um pixel para armazenar a cor media

    corMedia.r = totalR / count; // calcula a cor media de cada cor
    corMedia.g = totalG / count; // calcula a cor media de cada cor
    corMedia.b = totalB / count; // calcula a cor media de cada cor

    return corMedia; // retorna a cor media
}

// Limpa a memória ocupada pela árvore
void clearTree(QuadNode *n)
{
    if (n == NULL)
        return;
    if (n->status == PARCIAL)
    {
        clearTree(n->NE);
        clearTree(n->NW);
        clearTree(n->SE);
        clearTree(n->SW);
    }
    // printf("Liberando... %d - %.2f %.2f %.2f %.2f\n", n->status, n->x, n->y, n->width, n->height);
    free(n);
}

// Ativa/desativa o desenho das bordas de cada região
void toggleBorder()
{
    desenhaBorda = !desenhaBorda;
    printf("Desenhando borda: %s\n", desenhaBorda ? "SIM" : "NÃO");
}

// Desenha toda a quadtree
void drawTree(QuadNode *raiz)
{
    if (raiz != NULL)
        drawNode(raiz);
}

// Grava a árvore no formato do Graphviz
void writeTree(QuadNode *raiz)
{
    FILE *fp = fopen("quad.dot", "w");
    fprintf(fp, "digraph quadtree {\n");
    if (raiz != NULL)
        writeNode(fp, raiz);
    fprintf(fp, "}\n");
    fclose(fp);
    printf("\nFim!\n");
}

void writeNode(FILE *fp, QuadNode *n)
{
    if (n == NULL)
        return;

    if (n->NE != NULL)
        fprintf(fp, "%d -> %d;\n", n->id, n->NE->id);
    if (n->NW != NULL)
        fprintf(fp, "%d -> %d;\n", n->id, n->NW->id);
    if (n->SE != NULL)
        fprintf(fp, "%d -> %d;\n", n->id, n->SE->id);
    if (n->SW != NULL)
        fprintf(fp, "%d -> %d;\n", n->id, n->SW->id);
    writeNode(fp, n->NE);
    writeNode(fp, n->NW);
    writeNode(fp, n->SE);
    writeNode(fp, n->SW);
}

// Desenha todos os nodos da quadtree, recursivamente
void drawNode(QuadNode *n)
{
    if (n == NULL)
        return;

    glLineWidth(0.1);

    if (n->status == CHEIO)
    {
        glBegin(GL_QUADS);
        glColor3ubv(n->color);
        glVertex2f(n->x, n->y);
        glVertex2f(n->x + n->width - 1, n->y);
        glVertex2f(n->x + n->width - 1, n->y + n->height - 1);
        glVertex2f(n->x, n->y + n->height - 1);
        glEnd();
    }

    else if (n->status == PARCIAL)
    {
        if (desenhaBorda)
        {
            glBegin(GL_LINE_LOOP);
            glColor3ubv(n->color);
            glVertex2f(n->x, n->y);
            glVertex2f(n->x + n->width - 1, n->y);
            glVertex2f(n->x + n->width - 1, n->y + n->height - 1);
            glVertex2f(n->x, n->y + n->height - 1);
            glEnd();
        }
        drawNode(n->NE);
        drawNode(n->NW);
        drawNode(n->SE);
        drawNode(n->SW);
    }
    // Nodos vazios não precisam ser desenhados... nem armazenados!
}
