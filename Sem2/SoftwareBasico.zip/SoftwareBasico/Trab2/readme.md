# Dificuldades
    No inicio foi muito complexo a implementação da Quadtree recursiva, o que nos deu muito trabalho foi encontrar a forma mais correta de fazer a implementação de parada. verificando se o próprio nodo é uma folha ou se ele é um anterior as folhas. (por conta da falta do minError era complicada essa definição)

    Para calcular a cor media de cada regiao foi feito uma função que retorna a media de cada cor daquela regiao, somando as cores de cada pixel e dividindo pelo total de pixels

    Após isso foi se tornando um desafio a compreenção do histograma, como ele funcionaria e como poderiamos implementa-lo
    encontramos o [256] = {0} que inicializa todas as posições com o valor 0, e fomos somando 1 ao valor encontrado por exemplo histograma =[1. 0, 2] -> histograma[2]++ -> histograma = [1,0,3]

    O nivel de erro foi a maior dificuldade do trabalho, conseguimos fazer duas implementações principais, a primeira nos retornava um numero negativo e a segunda nos retorna 0, infelizmente fomos infelizes nessa solução já que não conseguimos resolver o problema, nem encontra-lo. Uma teoria que temos é que o bug está no inicio do algoritmo, desde sua base. Porém só teorizamos isso muito em cima da hora, se tornando inviavel o reinicio do projeto.

    Criamos inclusive uma função para nos retornar a media em uma tentativa de modularizarmos o programa e descobrir o maldito erro que nos perseguia, mais uma tentativa frustrada.
