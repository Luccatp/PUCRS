#include "quadtree.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#ifdef __APPLE__
#include <OpenGL/gl.h>
#else
#include <GL/gl.h>     /* OpenGL functions */
#endif

unsigned int first = 1;
char desenhaBorda = 1;
float minDetailG = 0;

QuadNode* newNode(int x, int y, int width, int height)
{
    QuadNode* n = malloc(sizeof(QuadNode));
    n->x = x;
    n->y = y;
    n->width = width;
    n->height = height;
    n->NW = n->NE = n->SW = n->SE = NULL;
    n->color[0] = n->color[1] = n->color[2] = 0;
    n->id = first++;
    return n;
}

QuadNode* geraQuadtreeRecursivo(Img* img, int x, int y, int width, int height, float minDetail);
float calculaCorMedia(Img* img, QuadNode* no);
float histoRegiao(Img* img, QuadNode* no, float media);

QuadNode* geraQuadtree(Img* img, float minDetail) {
    minDetailG = minDetail;
    // Crie o nó raiz da quadtree
    QuadNode* raiz = geraQuadtreeRecursivo(img, 0, 0, img->width, img->height, minDetail);

    return raiz;
}

QuadNode* geraQuadtreeRecursivo(Img* img, int x, int y, int width, int height, float minDetail) {
    // Crie um novo nó para a região atual
    QuadNode* node = newNode(x, y, width, height);
    float media = calculaCorMedia(img, node);
    float err = histoRegiao(img, node, media);

    // Verifique se todos os pixels na região têm a mesma cor
    int pixelIndex = y * img->width + x;
    RGBPixel firstPixel = img->img[pixelIndex];
    bool allSameColor = true;

    for (int i = y; i < y + height; i++) {
        for (int j = x; j < x + width; j++) {
            pixelIndex = i * img->width + j;
            RGBPixel currentPixel = img->img[pixelIndex];

            if (currentPixel.r != firstPixel.r || currentPixel.g != firstPixel.g || currentPixel.b != firstPixel.b) {
                allSameColor = false;
                break;
            }
        }

        if (!allSameColor) {
            break;
        }
    }

    if (allSameColor) {
        // Defina o status como CHEIO e a cor com base no primeiro pixel da imagem
        node->status = CHEIO;
        node->color[0] = firstPixel.r;
        node->color[1] = firstPixel.g;
        node->color[2] = firstPixel.b;

        // Como é uma folha, os filhos são definidos como NULL
        node->NW = NULL;
        node->NE = NULL;
        node->SW = NULL;
        node->SE = NULL;
    } else if (err >= minDetail || width <= 1 || height <= 1) { // talvez mudar para 2 ajude ainda mais -----------------------------
        // Defina o status como PARCIAL e a cor média com base nos pixels da imagem
        node->status = PARCIAL; // talvez comentar isso aqui -----------------------------------------
        int avgR = 0, avgG = 0, avgB = 0;

        for (int i = y; i < y + height; i++) {
            for (int j = x; j < x + width; j++) {
                pixelIndex = i * img->width + j;
                avgR += img->img[pixelIndex].r;
                avgG += img->img[pixelIndex].g;
                avgB += img->img[pixelIndex].b;
            }
        }

        int numPixels = width * height;
        node->color[0] = avgR / numPixels;
        node->color[1] = avgG / numPixels;
        node->color[2] = avgB / numPixels;

        // Como é uma folha, os filhos são definidos como NULL
        node->NW = NULL;
        node->NE = NULL;
        node->SW = NULL;
        node->SE = NULL;
    } else {
        // Divida a região em quatro quadrantes e gere a quadtree para cada um
        int halfWidth = width / 2;
        int halfHeight = height / 2;

        node->NW = geraQuadtreeRecursivo(img, x, y, halfWidth, halfHeight, minDetail);
        node->NE = geraQuadtreeRecursivo(img, x + halfWidth, y, width - halfWidth, halfHeight, minDetail);
        node->SW = geraQuadtreeRecursivo(img, x, y + halfHeight, halfWidth, height - halfHeight, minDetail);
        node->SE = geraQuadtreeRecursivo(img, x + halfWidth, y + halfHeight, width - halfWidth, height - halfHeight, minDetail);

        // Verifique se a região é parcialmente preenchida
        if (node->NW->status == PARCIAL || node->NE->status == PARCIAL ||
            node->SW->status == PARCIAL || node->SE->status == PARCIAL) {
            node->status = PARCIAL;
        } else if (node->NW->status == CHEIO && node->NE->status == CHEIO &&
        node->SW->status == CHEIO && node->SE->status == CHEIO) {
            node->status = CHEIO;

            // Combine as cores médias dos quadrantes
            node->color[0] = (node->NW->color[0] + node->NE->color[0] + node->SW->color[0] + node->SE->color[0]) / 4;
            node->color[1] = (node->NW->color[1] + node->NE->color[1] + node->SW->color[1] + node->SE->color[1]) / 4;
            node->color[2] = (node->NW->color[2] + node->NE->color[2] + node->SW->color[2] + node->SE->color[2]) / 4;

            // Libere a memória dos quadrantes filhos
            clearTree(node->NW);
            clearTree(node->NE);
            clearTree(node->SW);
            clearTree(node->SE);

            // Como é uma folha, os filhos são definidos como NULL
            node->NW = NULL;
            node->NE = NULL;
            node->SW = NULL;
            node->SE = NULL;

        } else {
            node->status = PARCIAL;
        }
    }

    return node;
}

void converteParaTonsDeCinza(Img* img) {
    for (int i = 0; i < img->width * img->height; i++) {
        unsigned char r = img->img[i].r;
        unsigned char g = img->img[i].g;
        unsigned char b = img->img[i].b;
        unsigned char gray = (unsigned char)(0.3 * r + 0.59 * g + 0.11 * b);
        img->img[i].r = gray;
        img->img[i].g = gray;
        img->img[i].b = gray;
    }
}

float histoRegiao(Img* img, QuadNode* no, float media) {
    int histograma[256] = {0}; // inicializa o histograma com zeros
    for (int i = no->y; i < no->y + no->height; i++) {
        for (int j = no->x; j < no->x + no->width; j++) {
            unsigned char gray = img->img[i * img->width + j].r;
            histograma[gray]++;
        }
    }
    
    int numPixels = no->width * no->height;
    float erro = 0.0;
    
    for (int i = 0; i < 256; i++) {
        float diff = i - media;
        erro += diff * diff * histograma[i];
    }
    
    erro /= numPixels;
    float e = sqrt((1.0 / (no->width * no->height)) * erro);
    //printf("%.2f\n", e);
    return e;
}


float calculaCorMedia(Img* img, QuadNode* no) {
    int numPixels = no->width * no->height;
    int soma = 0;
    float media = 0.0;
    for (int i = no->x; i < no->x + no->height; i++) {
        for (int j = no->y; j < no->y + no->width; j++) {
            unsigned char valorPixel = img->img[i * img->width + j].r;
            soma += valorPixel;
        }
    }
    if (numPixels != 0) { // Evita divisão por zero VERIFICAR ISSO ----------------------------------------------------
        media = soma / numPixels;
    }
    return media;
}


void geraEExibeHistograma(Img* img, QuadNode* no) {
    int histograma[256] = {0}; // inicializa o histograma com zeros
    for (int i = no->y; i < no->y + no->height; i++) {
        for (int j = no->x; j < no->x + no->width; j++) {
            unsigned char gray = img->img[i * img->width + j].r;
            histograma[gray]++;
        }
    }
    // Agora o histograma contém a frequência de cada tom de cinza dentro da região
    FILE* gnuplotPipe = popen("gnuplot -persistent", "w");
    fprintf(gnuplotPipe, "set boxwidth 1\n");
    fprintf(gnuplotPipe, "set style fill solid\n");
    fprintf(gnuplotPipe, "set xrange [0:256]\n");
    fprintf(gnuplotPipe, "plot '-' using 1:2 with boxes\n");
    for (int i = 0; i < 256; i++) {
        fprintf(gnuplotPipe, "%d %d\n", i, histograma[i]);
    }
    fprintf(gnuplotPipe, "e\n");
    fflush(gnuplotPipe);
    pclose(gnuplotPipe);
}

// Limpa a memória ocupada pela árvore
void clearTree(QuadNode* n)
{
    if(n == NULL) return;
    if(n->status == PARCIAL)
    {
        clearTree(n->NE);
        clearTree(n->NW);
        clearTree(n->SE);
        clearTree(n->SW);
    }
    //printf("Liberando... %d - %.2f %.2f %.2f %.2f\n", n->status, n->x, n->y, n->width, n->height);
    free(n);
}

// Ativa/desativa o desenho das bordas de cada região
void toggleBorder() {
    desenhaBorda = !desenhaBorda;
    printf("Desenhando borda: %s\n", desenhaBorda ? "SIM" : "NÃO");
}

// Desenha toda a quadtree
void drawTree(QuadNode* raiz) {
    if(raiz != NULL)
        drawNode(raiz);
}

// Grava a árvore no formato do Graphviz
void writeTree(QuadNode* raiz) {
    FILE* fp = fopen("quad_batata.dot", "w");
    fprintf(fp, "digraph quadtree {\n");
    if (raiz != NULL)
        writeNode(fp, raiz);
    fprintf(fp, "}\n");
    fclose(fp);
    printf("\nFim!\n");
}

void writeNode(FILE* fp, QuadNode* n)
{
    if(n == NULL) return;

    if(n->NE != NULL) fprintf(fp, "%d -> %d;\n", n->id, n->NE->id);
    if(n->NW != NULL) fprintf(fp, "%d -> %d;\n", n->id, n->NW->id);
    if(n->SE != NULL) fprintf(fp, "%d -> %d;\n", n->id, n->SE->id);
    if(n->SW != NULL) fprintf(fp, "%d -> %d;\n", n->id, n->SW->id);
    writeNode(fp, n->NE);
    writeNode(fp, n->NW);
    writeNode(fp, n->SE);
    writeNode(fp, n->SW);
}

// Desenha todos os nodos da quadtree, recursivamente
void drawNode(QuadNode* n)
{

    if(n == NULL) return;

    glLineWidth(0.1);

    if(n->status == CHEIO) {
        glBegin(GL_QUADS);
        glColor3ubv(n->color);
        glVertex2f(n->x, n->y);
        glVertex2f(n->x+n->width-1, n->y);
        glVertex2f(n->x+n->width-1, n->y+n->height-1);
        glVertex2f(n->x, n->y+n->height-1);
        glEnd();
    }

    else if(n->status == PARCIAL)
    {
        if(desenhaBorda) {
            glBegin(GL_LINE_LOOP);
            glColor3ubv(n->color);
            glVertex2f(n->x, n->y);
            glVertex2f(n->x+n->width-1, n->y);
            glVertex2f(n->x+n->width-1, n->y+n->height-1);
            glVertex2f(n->x, n->y+n->height-1);
            glEnd();
        }
        drawNode(n->NE);
        drawNode(n->NW);
        drawNode(n->SE);
        drawNode(n->SW);
    }
    // Nodos vazios não precisam ser desenhados... nem armazenados!
}

