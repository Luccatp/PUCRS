import java.util.LinkedList;
import java.util.List;

public class Node {

    private final int[][] value;
    private final Node parent;
    private final int[] zeroPosition;
    private List<Node> children;

    /**
     * Construtor da classe Node.
     *
     * @param value  a matriz associada a este nó
     * @param parent o nó pai deste nó na árvore de busca
     */
    public Node(int[][] value, Node parent) {
        this.value = value;
        this.parent = parent;
        this.children = new LinkedList<>();

        zeroPosition = ArrayTransformations.findIndexInMatrix(value, 0);
    }

    /**
     * Adiciona um filho a este nó.
     *
     * @param value a matriz associada ao novo nó filho
     * @return      o nó filho adicionado
     */
    public Node addChild(int[][] value) {
        Node newChild = new Node(value, this);
        children.add(newChild);
        return newChild;
    }

    /**
     * Obtém a posição do zero na matriz associada a este nó.
     *
     * @return array contendo as coordenadas (x, y) do zero na matriz
     */
    public int[] getZeroPosition() {
        return zeroPosition;
    }

    /**
     * Obtém a matriz associada a este nó.
     *
     * @return a matriz associada a este nó
     */
    public int[][] getValue() {
        return value;
    }

    /**
     * Obtém a lista de filhos deste nó.
     *
     * @return a lista de filhos deste nó
     */
    public List<Node> getChildren() {
        return children;
    }

    /**
     * Obtém o nó pai deste nó na árvore de busca.
     *
     * @return o nó pai deste nó na árvore de busca
     */
    public Node getParent() {
        return parent;
    }
}
