public interface DepthFirstInterface {
    void solveDepthFirst (int[][] initialMatrix, int[][] finalMatrix, int x, int y);
}
