public interface AStarInterface {

    void solveAStar (int[][] initialMatrix, int[][] finalMatrix, int x, int y);
}
