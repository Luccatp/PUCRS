public interface BreadthFirstInterface {
    void solveBreadthFirst (int[][] initialMatrix, int[][] finalMatrix, int x, int y);
}
