
public class Main {
    public static void main(String[] args) {
        int[][] matrix1 = {
                {1, 2, 3},
                {4, 5, 6},
                {0, 7, 8}
        };

        int[][] matrix2 = {
                {1, 3, 0},
                {4, 2, 5},
                {7, 8, 6}
        };

        int[][] matrix3 = {
                {1, 3, 5},
                {2, 6, 0},
                {4, 7, 8}
        };

        int[][] matrix4 = {
                {1, 8, 3},
                {4, 2, 6},
                {7, 5, 0}
        };

        int[][] matrix5 = {
                {1, 2, 3},
                {7, 0, 6},
                {4, 8, 5}
        };




        int[][] finalMatrix = {
                {1, 2, 3},
                {4, 5, 6},
                {7, 8, 0}
        };

        BreadthFirst breadthFirst = new BreadthFirst();
        DepthFirst depthFirst = new DepthFirst();
        GreedyBestFirst greedyBestFirst = new GreedyBestFirst();
        AStar aStar = new AStar();
//		breadthFirst.solveBreadthFirst(matrix1, finalMatrix, 0,2);
	depthFirst.solveDepthFirst(matrix5, finalMatrix, 2, 0);
//		greedyBestFirst.solveGreedyBestFirst(matrix5, finalMatrix, 2, 0);
//        aStar.solveAStar(matrix5, finalMatrix, 2, 0);
    }
}
