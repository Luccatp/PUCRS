package com.ai.trab2.services.interfaces;

public interface GreedyBestFirstInterface {

    void solveGreedyBestFirst (int[][] initialMatrix, int[][] finalMatrix, int x, int y);
}
