package com.ai.trab2.services.interfaces;

public interface BreadthFirstInterface {
    void solveBreadthFirst (int[][] initialMatrix, int[][] finalMatrix, int x, int y);
}
