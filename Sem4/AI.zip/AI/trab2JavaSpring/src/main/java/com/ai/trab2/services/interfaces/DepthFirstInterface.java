package com.ai.trab2.services.interfaces;

public interface DepthFirstInterface {
    void solveDepthFirst (int[][] initialMatrix, int[][] finalMatrix, int x, int y);
}
