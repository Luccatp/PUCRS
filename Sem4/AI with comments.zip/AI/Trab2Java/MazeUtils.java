/**
 * Classe utilitária para o quebra-cabeça.
 */
public class MazeUtils {

    /**
     * Imprime a solução do quebra-cabeça, incluindo a matriz de cada nó, estatísticas sobre o número de nós criados,
     * o número de nós visitados e a profundidade da árvore.
     *
     * @param node                  o nó final da solução
     * @param numberOfNodesCreated o número total de nós criados durante a busca
     * @param getNumberOfNodesVisited o número total de nós visitados durante a busca
     */
    public static void printSolution(Node node, int numberOfNodesCreated, int getNumberOfNodesVisited) {
        int treeDepth = 0;

        System.out.println("Solution found:");
        while (node != null) {
            treeDepth++;
            ArrayTransformations.printMatrix(node.getValue());
            System.out.println();
            node = node.getParent();
        }
        System.out.println("Number of nodes created: " + numberOfNodesCreated);
        System.out.println("Number of nodes visited: " + getNumberOfNodesVisited);
        System.out.println("Tree depth: " + treeDepth);
    }
}
