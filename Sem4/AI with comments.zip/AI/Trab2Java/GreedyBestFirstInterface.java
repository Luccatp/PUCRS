public interface GreedyBestFirstInterface {

    void solveGreedyBestFirst (int[][] initialMatrix, int[][] finalMatrix, int x, int y);
}
